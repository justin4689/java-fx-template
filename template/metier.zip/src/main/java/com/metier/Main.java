package com.metier;

import com.metier.service.NavigationService;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        NavigationService nav = NavigationService.getInstance();
        nav.setStage(primaryStage);
        nav.navigateTo("login.fxml");
    }
}