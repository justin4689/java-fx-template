package com.metier.controller;

import com.metier.model.User;
import com.metier.service.NavigationService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * Contrôleur d'inscription - Gère la création de comptes utilisateur
 * Conforme au pattern MVC avec validation des champs
 */
public class RegisterController {
    @FXML private TextField fullNameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmField;

    @FXML
    private void handleRegister() {
        // Validation des champs vides
        if (fullNameField.getText().isEmpty() || emailField.getText().isEmpty() ||
                passwordField.getText().isEmpty() || confirmField.getText().isEmpty()) {
            showError("Champs requis", "Tous les champs doivent être remplis");
            return;
        }

        // Validation des mots de passe
        if (!passwordField.getText().equals(confirmField.getText())) {
            showError("Erreur de validation", "Les mots de passe ne correspondent pas");
            return;
        }

        // Création du modèle utilisateur
        User newUser = new User(
                emailField.getText(),
                fullNameField.getText(),
                passwordField.getText()
        );

        // En mode MOCK : Simulation de sauvegarde
        System.out.println("✅ Utilisateur créé : " + newUser.getEmail());
        showInfo("Succès", "Compte créé avec succès !");

        // Redirection vers le login
        goToLogin();
    }

    @FXML
    private void goToLogin() {
        try {
            NavigationService.getInstance().navigateTo("login.fxml");
        } catch (Exception e) {
            showError("Navigation impossible", e.getMessage());
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.show();
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.show();
    }
}