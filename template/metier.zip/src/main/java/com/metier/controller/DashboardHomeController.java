package com.metier.controller;

import com.metier.model.UserSync;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Contrôleur spécifique au dashboard home
 * Implémente Initializable pour un meilleur contrôle du cycle de vie
 */
public class DashboardHomeController implements Initializable {
    @FXML private TableView<UserSync> usersTable;
    @FXML private TableColumn<UserSync, String> colNom;
    @FXML private TableColumn<UserSync, String> colAgence;
    @FXML private TableColumn<UserSync, String> colSynchro;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTable();
        loadData();
    }

    private void setupTable() {
        // Binding des colonnes avec les propriétés du modèle
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colAgence.setCellValueFactory(new PropertyValueFactory<>("agence"));
        colSynchro.setCellValueFactory(new PropertyValueFactory<>("synchro"));
    }

    private void loadData() {
        // Données mockées - En production : appeler un service
        ObservableList<UserSync> data = FXCollections.observableArrayList(
                new UserSync("Marie-Paul Ben", "San-Pedro", "22/10/2020 (17h30)"),
                new UserSync("Madi Bali", "Bouake", "22/10/2020 (17h36)")
        );

        usersTable.setItems(data);
    }
}