package com.metier.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.StackPane;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Contrôleur principal du dashboard - Gère l'injection du menu
 * Conforme au pattern de contrôleur imbriqué avec fx:include
 */
public class DashboardController implements Initializable {
    @FXML private StackPane contentArea;
    @FXML private MenuController menuController; // Injection automatique via fx:id

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Le menuController est automatiquement injecté grâce à fx:id="menu"
        // On lui passe la référence au contentArea pour qu'il puisse charger les vues
        menuController.setContentArea(contentArea);
    }
}