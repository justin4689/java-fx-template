src/main/java/com/metier/
├── Main.java
├── controller/
│   ├── LoginController.java
│   ├── RegisterController.java
│   ├── DashboardController.java
│   └── MenuController.java
└── service/
    └── NavigationService.java

src/main/resources/com/metier/view/
├── login-view.fxml
├── register-view.fxml
├── dashboard-view.fxml
├── menu-view.fxml
├── dashboard-home-view.fxml
├── clients-view.fxml
├── projects-view.fxml
├── reports-view.fxml
├── settings-view.fxml
├── training-view.fxml
├── support-view.fxml
└── styles.css


# Coordonnee de connexion
admin@metier.com / admin123

# Nettoie, compile et lance
mvn clean compile javafx:run