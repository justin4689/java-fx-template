package com.metier.model;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 * Modèle pour une carte statistique
 * Conforme aux conventions JavaBean avec Property<T>
 */
public class StatData {
    private final SimpleStringProperty title = new SimpleStringProperty();
    private final SimpleDoubleProperty value = new SimpleDoubleProperty();
    private final SimpleStringProperty unit = new SimpleStringProperty();
    private final SimpleStringProperty trend = new SimpleStringProperty();
    private final SimpleStringProperty trendColor = new SimpleStringProperty();

    public StatData() {}

    public StatData(String title, double value, String unit, String trend, String trendColor) {
        setTitle(title);
        setValue(value);
        setUnit(unit);
        setTrend(trend);
        setTrendColor(trendColor);
    }

    public String getTitle() { return title.get(); }
    public void setTitle(String value) { title.set(value); }
    public SimpleStringProperty titleProperty() { return title; }

    public double getValue() { return value.get(); }
    public void setValue(double value) { this.value.set(value); }
    public SimpleDoubleProperty valueProperty() { return value; }

    public String getUnit() { return unit.get(); }
    public void setUnit(String value) { unit.set(value); }
    public SimpleStringProperty unitProperty() { return unit; }

    public String getTrend() { return trend.get(); }
    public void setTrend(String value) { trend.set(value); }
    public SimpleStringProperty trendProperty() { return trend; }

    public String getTrendColor() { return trendColor.get(); }
    public void setTrendColor(String value) { trendColor.set(value); }
    public SimpleStringProperty trendColorProperty() { return trendColor; }
}