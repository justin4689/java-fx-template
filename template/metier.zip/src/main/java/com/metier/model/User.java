package com.metier.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Modèle utilisateur conforme aux conventions JavaBean
 * Utilise des Property<T> pour le binding réactif
 */
public class User {
    private final StringProperty email = new SimpleStringProperty();
    private final StringProperty fullName = new SimpleStringProperty();
    private final StringProperty password = new SimpleStringProperty();

    public User() {}

    public User(String email, String fullName, String password) {
        setEmail(email);
        setFullName(fullName);
        setPassword(password);
    }

    // Email
    public String getEmail() { return email.get(); }
    public void setEmail(String value) { email.set(value); }
    public StringProperty emailProperty() { return email; }

    // FullName
    public String getFullName() { return fullName.get(); }
    public void setFullName(String value) { fullName.set(value); }
    public StringProperty fullNameProperty() { return fullName; }

    // Password
    public String getPassword() { return password.get(); }
    public void setPassword(String value) { password.set(value); }
    public StringProperty passwordProperty() { return password; }
}