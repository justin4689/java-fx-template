package com.metier.model;

public class UserSync {
    private String nom;
    private String agence;
    private String synchro;

    public UserSync(String nom, String agence, String synchro) {
        this.nom = nom;
        this.agence = agence;
        this.synchro = synchro;
    }

    public String getNom() { return nom; }
    public String getAgence() { return agence; }
    public String getSynchro() { return synchro; }
}