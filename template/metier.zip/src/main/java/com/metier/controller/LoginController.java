package com.metier.controller;

import com.metier.model.User;
import com.metier.service.NavigationService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * Contrôleur de login - Gère l'authentification utilisateur
 * Conforme au pattern MVC avec séparation stricte Model/View
 */
public class LoginController {
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;

    // Données mockées (remplacer par service d'authentification réel)
    private static final String MOCK_EMAIL = "admin@metier.com";
    private static final String MOCK_PASS = "admin123";

    @FXML
    private void handleLogin() {
        if (MOCK_EMAIL.equals(emailField.getText()) && MOCK_PASS.equals(passwordField.getText())) {
            try {
                // Création du modèle utilisateur (conforme à la doc)
                User currentUser = new User(MOCK_EMAIL, "Administrateur", MOCK_PASS);
                // En production : utiliser un service d'authentification
                NavigationService.getInstance().navigateTo("dashboard.fxml");
            } catch (Exception e) {
                showError("Erreur de navigation", e.getMessage());
            }
        } else {
            showError("Identifiants incorrects", "Email ou mot de passe invalide");
        }
    }

    @FXML
    private void goToRegister() {
        try {
            NavigationService.getInstance().navigateTo("register.fxml");
        } catch (Exception e) {
            showError("Navigation impossible", e.getMessage());
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.show();
    }
}